from django.contrib import admin

# Register your models here.
# register Destination model
from .models import Destination
admin.site.register(Destination)