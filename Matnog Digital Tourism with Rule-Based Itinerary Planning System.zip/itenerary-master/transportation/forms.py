from django import forms
from django.contrib.contenttypes.models import ContentType
from .models import Transportation
from destination.models import Destination
from accommodation.models import Accommodation



class TransportationForm(forms.ModelForm):
    class Meta:
        model = Transportation
        fields = '__all__'
        widgets = {}
        exclude = ('created_by','is_active')


    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control',
                                       'autocomplete': 'on'
                                       })

            if isinstance(field, forms.BooleanField):
                field.widget.attrs.update({'class': 'form-check-input'})

        if 'description' in self.fields:
            self.fields['description'].widget.attrs['style'] = 'height: 150px;'