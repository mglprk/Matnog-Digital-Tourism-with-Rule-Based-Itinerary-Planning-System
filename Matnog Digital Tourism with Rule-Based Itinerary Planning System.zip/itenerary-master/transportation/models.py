from django.db import models


class Transportation(models.Model):
    HUB_TYPES = [
        ('airport', 'Airport'),
        ('bus_stop', 'Bus Stop'),
        ('jeepney_stop', 'Jeepney Stop'),
        ('tricycle_stop', 'Tricycle Stop'),
        ('ferry_terminal', 'Ferry Terminal'),
        ('train_station', 'Train Station'),
        ('parking_area', 'Parking Area'),
    ]
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('closed', 'Temporarily Closed'),
    ]

    name = models.CharField(max_length=255)
    hub_type = models.CharField(max_length=50, choices=HUB_TYPES)
    description = models.TextField(blank=True, null=True)


    # --- Location ---
    address = models.CharField(max_length=255, blank=True, null=True)
    latitude = models.DecimalField(max_digits=17, decimal_places=15, blank=True, null=True)
    longitude = models.DecimalField(max_digits=17, decimal_places=14, blank=True, null=True)

    # --- Management ---
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey('auth.User', on_delete=models.SET_NULL, null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.get_hub_type_display()})"


# TODO: add hub pictures and posts models later

# class Fare(models.Model):
#     origin = models.ForeignKey(TransportationHub, related_name='fares_from', on_delete=models.CASCADE)
#     destination = models.ForeignKey(TransportationHub, related_name='fares_to', on_delete=models.CASCADE)
#     mode = models.CharField(max_length=50, choices=[('bus', 'Bus'), ('tricycle', 'Tricycle'), ('van', 'Van')])
#     cost = models.DecimalField(max_digits=10, decimal_places=2)
#     estimated_time_minutes = models.IntegerField()