from django.urls import path

from transportation import views

urlpatterns = [
    path('', views.transportation_view, name='transportation'),
    path('add', views.transportation_add, name='transportation_add'),
    path('<int:pk>', views.transportation_edit, name='transportation_edit'),
    path('delete/<int:pk>/', views.transportation_delete, name='transportation_delete'),

]
