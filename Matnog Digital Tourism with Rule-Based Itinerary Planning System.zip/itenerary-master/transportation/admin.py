from django.contrib import admin

from transportation.models import Transportation

# Register your models here.
admin.site.register(Transportation)