from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

from config.decorator import permission_required
from transportation.forms import TransportationForm
from transportation.models import Transportation
from config import settings


# Create your views here.

mapbox_access_token = settings.MAPBOX_PUBLIC_TOKEN


@permission_required('can_view_transportations')
def transportation_view(request):
    transportations = Transportation.objects.all().order_by('-id')

    return render(request, 'administrator/admin/transportations/transportations.html', {
        'transportations': transportations
    })

@permission_required('can_manage_transportations')
def transportation_add(request):
    form = TransportationForm()
    if request.method == 'POST':

        form = TransportationForm(request.POST, request.FILES)
        if form.is_valid():
            # set the user who created this transportation
            form = form.save(commit=False)
            form.created_by = request.user
            form.is_active = True
            form.save()
            messages.success(request, 'Transportation added successfully.')
            return redirect('transportation')
        else:
            for field, errors in form.errors.items():
                field_label = form.fields[field].label or field.capitalize()
                # Make message more natural: "Name field is required."
                error_message = f"{field_label} field {' '.join(errors).replace('This field', '').strip().capitalize()}."
                messages.error(request, error_message)

    return render(request, 'administrator/admin/transportations/transportation_add.html', {
        'form': form,
        'mapbox_access_token': mapbox_access_token
    })

@permission_required('can_manage_transportations')
def transportation_edit(request, pk):
    transportation = Transportation.objects.get(id=pk)
    form = TransportationForm(instance=transportation)
    if request.method == 'POST':
        form = TransportationForm(request.POST, request.FILES, instance=transportation)
        if form.is_valid():
            form = form.save(commit=False)
            form.created_by = transportation.created_by
            form.is_active = transportation.is_active
            form.save()
            messages.success(request, 'Transportation updated successfully.')
            return redirect('transportation')
        else:
            for field, errors in form.errors.items():
                field_label = form.fields[field].label or field.capitalize()
                # Make message more natural: "Name field is required."
                error_message = f"{field_label} field {' '.join(errors).replace('This field', '').strip().capitalize()}."
                messages.error(request, error_message)

    return render(request, 'administrator/admin/transportations/transportation_add.html', {
        'form': form,
        'transportation': transportation,
        'mapbox_access_token': mapbox_access_token
    })

@permission_required('can_manage_transportations')
def transportation_delete(request, pk):
    trans = Transportation.objects.get(id=pk)
    trans.delete()
    messages.success(request, 'Transportation deleted successfully.')
    return redirect('transportation')