from django.contrib import admin

from accommodation.models import Accommodation

# Register your models here.
admin.site.register(Accommodation)